import { useMemo, useState } from 'react';
import { useAppState } from './context/AppStateContext';
import { CLEANING_RULES, TYPE_BADGE_STYLE } from './data/mockData';
import { cx } from './utils/cx';

/* =============================================================================
 * 智慧学伴 · 学情数据分析（页面 3 / Tab1~Tab3）
 * -----------------------------------------------------------------------------
 * 注意：顶部导航与左侧筛选栏已由 AppLayout 提供，本文件只负责主内容区。
 * 设计令牌：主色 #88D8C0、页面底色 #F8FBFA、卡片底色 #EDF6F3、提醒色 #FFF3D9、
 * 警示色 #F9E7E7、正文 #334442、次要文字 #708480、分割线 #D8E6E2
 * ========================================================================== */

/** 主内容区 Tab 配置 */
const TABS = [
  { key: 'quality', label: 'Tab1 数据质量报告' },
  { key: 'individual', label: 'Tab2 个体学情' },
  { key: 'group', label: 'Tab3 群体学情' },
];

/** 样例表格的列宽：学生ID / 题目编号 / 测验节点 / 异常缺失类型 / 数据状态 */
const TABLE_GRID = 'grid grid-cols-[1fr_1.2fr_1.2fr_1.6fr_1.2fr] items-center gap-4';

/** 警示三角（规则说明中的温馨提示） */
function AlertIcon({ className }) {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true" className={className}>
      <path
        d="M8 2.2 14.2 13a.6.6 0 0 1-.5.9H2.3a.6.6 0 0 1-.5-.9L8 2.2Z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <path d="M8 6.1v3.1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <circle cx="8" cy="11.2" r="0.7" fill="currentColor" />
    </svg>
  );
}

/* ================================ Tab 切换条 ============================== */

function TabBar({ activeTab, onChange }) {
  return (
    <div className="flex items-center gap-10 px-6">
      {TABS.map((tab) => {
        const active = tab.key === activeTab;
        return (
          <button
            key={tab.key}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(tab.key)}
            className={cx(
              'relative py-4 text-[13px] transition-colors',
              active ? 'font-semibold text-brand' : 'text-muted hover:text-ink'
            )}
          >
            {tab.label}
            {/* 选中态下划线：使用主色 */}
            <span
              aria-hidden="true"
              className={cx(
                'absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-brand transition-opacity',
                active ? 'opacity-100' : 'opacity-0'
              )}
            />
          </button>
        );
      })}
    </div>
  );
}

/* ================================ 指标卡片 ================================ */

function MetricCards({ metrics }) {
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {metrics.map((metric) => (
        <div key={metric.key} className="rounded-lg border border-line/60 bg-card px-6 py-4">
          <p className="text-xs text-muted">{metric.label}</p>
          <p className="mt-3 text-4xl font-bold leading-none tracking-tight text-ink tabular-nums">
            {metric.value}
          </p>
        </div>
      ))}
    </div>
  );
}

/* ========================= Tab1 数据质量报告内容 ========================= */

function QualityReport({ metrics, rows }) {
  return (
    <>
      {/* 核心指标区 */}
      <div className="px-6 pb-6">
        <MetricCards metrics={metrics} />
      </div>

      {/* 规则说明区 */}
      <section className="border-t border-line px-6 py-5">
        <h2 className="text-[13px] font-semibold text-ink">数据清洗规则说明</h2>

        <div className="mt-2.5 space-y-1 text-xs leading-6 text-muted">
          {CLEANING_RULES.map((rule) => (
            <p key={rule.key}>
              <span className="text-ink">{rule.title}</span>
              {rule.desc}
            </p>
          ))}
        </div>

        {/* 警示文字使用提醒色 #FFF3D9 打底强调 */}
        <p className="mt-3 inline-flex items-center gap-1.5 rounded bg-warn px-2.5 py-1.5 text-xs font-medium text-[#A9761C]">
          <AlertIcon className="h-3.5 w-3.5" />
          警示：信息不足 <span className="font-semibold">≠</span> 判定未掌握
        </p>
      </section>

      {/* 异常/缺失样例预览 */}
      <section className="border-t border-line px-6 py-5">
        <h2 className="text-[13px] font-semibold text-ink">异常/缺失样例预览</h2>

        <div className="mt-4 overflow-x-auto">
          <div className="min-w-[640px]">
            {/* 表头 */}
            <div
              className={cx(
                TABLE_GRID,
                'border-b border-line py-2.5 text-xs font-medium text-muted'
              )}
            >
              <span>学生ID</span>
              <span>题目编号</span>
              <span>测验节点</span>
              <span>异常/缺失类型</span>
              <span>数据状态</span>
            </div>

            {/* 数据行 */}
            {rows.map((row) => (
              <div
                key={`${row.studentId}-${row.questionId}`}
                className={cx(
                  TABLE_GRID,
                  'border-b border-line py-3.5 text-xs text-ink',
                  'transition-colors last:border-b-0 hover:bg-page/70'
                )}
              >
                <span className="font-medium">{row.studentId}</span>
                <span className="text-ink/80">{row.questionId}</span>
                <span className="text-ink/80">{row.node}</span>
                <span>
                  <span
                    className={cx(
                      'inline-flex items-center rounded px-2.5 py-1 font-medium',
                      TYPE_BADGE_STYLE[row.type]
                    )}
                  >
                    {row.type}
                  </span>
                </span>
                <span className="text-muted">{row.status}</span>
              </div>
            ))}

            {/* 筛选后无数据时的空状态 */}
            {rows.length === 0 && (
              <div className="py-10 text-center text-xs text-muted">
                当前筛选条件下暂无异常/缺失样例
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}

/* ================================ 占位面板 ================================ */

function PlaceholderPanel({ title, description }) {
  return (
    <div className="px-6 pb-6">
      <div className="flex h-[320px] flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-line bg-page/60">
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="text-xs text-muted">{description}</p>
      </div>
    </div>
  );
}

/* ================================ 页面组件 ================================ */

export default function DataQualityTab() {
  const { metrics, rows, studentId, status } = useAppState();
  const [activeTab, setActiveTab] = useState('quality');

  /** 根据已选学生、记录状态过滤样例数据 */
  const filteredRows = useMemo(
    () =>
      rows.filter(
        (row) =>
          (studentId === '全部学生' || row.studentId === studentId) &&
          (status === '全部状态' || row.type === status)
      ),
    [rows, studentId, status]
  );

  return (
    <section className="rounded-lg border border-line bg-white">
      <TabBar activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'quality' && <QualityReport metrics={metrics} rows={filteredRows} />}

      {activeTab === 'individual' &&
        (studentId === '全部学生' ? (
          <PlaceholderPanel
            title="尚未选择学生"
            description="请先在左侧「学生ID」下拉框中选择学生，再查看个体学情。"
          />
        ) : (
          <PlaceholderPanel
            title={`${studentId} · 个体学情`}
            description="图表占位区域（各知识点正确率柱状图、学情摘要表格待接入）"
          />
        ))}

      {activeTab === 'group' && (
        <PlaceholderPanel
          title="群体学情 · 全班"
          description="图表占位区域（班级平均正确率柱状图、共性问题表格待接入）"
        />
      )}
    </section>
  );
}
