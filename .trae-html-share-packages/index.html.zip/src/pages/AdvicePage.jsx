import PageScaffold from '../components/PageScaffold';
import { useAppState } from '../context/AppStateContext';

/** 页面 4：个性化学习建议（任务3 / M5），继承页面 3 已选学生 */
export default function AdvicePage() {
  const { studentId } = useAppState();
  const hasStudent = studentId !== '全部学生';

  return (
    <PageScaffold
      title="个性化学习建议"
      subtitle="基于个体学情证据生成学习建议，支持教师调整与证据链溯源。"
    >
      {/* 未选择学生时给出明确引导 */}
      {!hasStudent ? (
        <p className="mb-4 rounded-lg bg-warn px-4 py-3 text-xs font-medium text-[#A9761C]">
          请前往学情分析页面选择学生后，再查看个性化学习建议。
        </p>
      ) : (
        <p className="mb-4 rounded-lg bg-card px-4 py-3 text-xs text-muted">
          已继承学生：<span className="font-medium text-ink">{studentId}</span>
        </p>
      )}

      <div className="rounded-lg border border-dashed border-line bg-page/60 px-6 py-12 text-center">
        <p className="text-sm font-medium text-ink">页面内容待实现</p>
        <p className="mt-1.5 text-xs leading-6 text-muted">
          将包含：学生状态提示 · 学习建议卡片（顺序 / 内容 / 材料编号 / 理由 / 适用条件）·
          证据链弹窗 · 教师人机协同调整区 · 导出 JSON / CSV
        </p>
      </div>
    </PageScaffold>
  );
}
