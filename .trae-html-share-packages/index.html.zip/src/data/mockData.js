/**
 * 页面共享的模拟数据。
 * 后续接入真实接口时，只需把这里的常量替换为请求结果即可。
 */

/** 学生编号：完整学号 D01 ~ D40 */
export const STUDENT_OPTIONS = [
  '全部学生',
  ...Array.from({ length: 40 }, (_, index) => `D${String(index + 1).padStart(2, '0')}`),
];

/** 记录状态筛选：全部 / 缺失 / 异常 */
export const STATUS_OPTIONS = ['全部状态', '缺失记录', '异常越界'];

/** 顶部 4 个核心指标（key 用于“模拟新增记录”时精准累加） */
export const INITIAL_METRICS = [
  { key: 'total', label: '总记录', value: 806 },
  { key: 'missing', label: '缺失记录', value: 11 },
  { key: 'duplicate', label: '重复记录', value: 47 },
  { key: 'abnormal', label: '异常记录', value: 2 },
];

/** 数据清洗规则说明（title 加粗，desc 常规） */
export const CLEANING_RULES = [
  { key: 'missing', title: '缺失标记：', desc: '关键字段为空 → 标记为信息不足，不参与正确率计算' },
  { key: 'abnormal', title: '异常越界：', desc: '得分超出 [0,100] 范围 → 标记为异常数据，排除统计' },
  { key: 'duplicate', title: '重复合并：', desc: '同一学生同一知识点多条记录 → 保留最新一条' },
];

/** 异常/缺失样例 */
export const INITIAL_ROWS = [
  { studentId: 'D16', questionId: 'Q044', node: 'N01', type: '异常越界', status: '待修正' },
  { studentId: 'D26', questionId: 'Q034', node: 'N02', type: '异常越界', status: '待修正' },
  { studentId: 'D03', questionId: 'Q012', node: 'N01', type: '缺失记录', status: '待提交' },
  { studentId: 'D07', questionId: 'Q028', node: 'N02', type: '缺失记录', status: '待提交' },
];

/** 异常/缺失类型 → 标签配色（提醒色 / 警示色） */
export const TYPE_BADGE_STYLE = {
  缺失记录: 'bg-warn text-[#A9761C]',
  异常越界: 'bg-danger text-[#B4544F]',
};
